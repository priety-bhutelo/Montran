package com.montran.form;

import org.apache.struts.action.ActionForm;

public class UserDetailsForm extends ActionForm {

	private String userName;

	public String getUserName() {
		System.out.println("in getUserName()");
		return userName;
	}

	public void setUserName(String userName) {
		System.out.println("in setUserName()");
		this.userName = userName;
	}

}
