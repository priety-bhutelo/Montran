package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.form.UserLoginForm;

public class UserLoginAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		UserLoginForm loginForm = (UserLoginForm) form;
		if (loginForm.getUserId().equals("admin") && loginForm.getPassword().equals("p@ssw0rd"))
			return mapping.findForward("success");
		else
			return mapping.findForward("failure");
	}
}
