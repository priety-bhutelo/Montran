package com.montran.form;

import org.apache.struts.action.ActionForm;

public class LoginForm extends ActionForm {
	private String username;

	public String getUsername() {
		System.out.println("in getUsername");
		return username;
	}

	public void setUsername(String username) {
		System.out.println("in setUsername");
		this.username = username;
	}

}
