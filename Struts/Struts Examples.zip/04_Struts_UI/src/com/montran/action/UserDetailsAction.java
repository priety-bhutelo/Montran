package com.montran.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.form.UserDetailsForm;

public class UserDetailsAction extends Action {
	private List<String> languages;

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		UserDetailsForm userDetailsForm = (UserDetailsForm) form;
		languages = new ArrayList<String>(Arrays.asList(userDetailsForm.getLanguages()));

		request.setAttribute("languages", languages);
		return mapping.findForward("success");
	}
}
