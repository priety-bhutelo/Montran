package com.montran.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.Employee;
import com.montran.util.SessionFactoryUtil;

public class EmployeeDAO {
	private Session session;
	private Transaction transaction;
	private SessionFactory factory = SessionFactoryUtil.getFactory();

	public void addNewEmployee(Employee employee) {
		session = factory.openSession();
		transaction = session.beginTransaction();
		session.save(employee);
		transaction.commit();
		session.close();
	}

	public List<Employee> getAllEmployees() {
		session = factory.openSession();
		Query query = session.createQuery("from employee_struts_hibernate_master");
		List<Employee> employeeList = query.list();
		return employeeList;
	}
}
