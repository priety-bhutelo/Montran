package com.montran.form;

import org.apache.struts.action.ActionForm;

public class HelloWorldForm extends ActionForm {
	String message;

	public String getMessage() {
		System.out.println("in getMessage()");
		return message;
	}

	public void setMessage(String message) {
		System.out.println("in setMessage()");
		this.message = message;
	}
}
