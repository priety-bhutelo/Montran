package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.dao.EmployeeDAO;
import com.montran.form.EmployeeForm;
import com.montran.pojo.Employee;

public class AddNewEmployeeAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		// getting employeeForm object
		EmployeeForm employeeForm = (EmployeeForm) form;
		System.out.println("employeeForm object is set");

		// transfering data from employeeForm to new EmployeeObject
		Employee employee = new Employee();
		employee.setEmployeeId(employeeForm.getEmployeeId());
		employee.setName(employeeForm.getName());
		employee.setSalary(employeeForm.getSalary());
		System.out.println(employee);

		// pass new EmployeeObject to Hibernate :: insert into database
		EmployeeDAO dao = new EmployeeDAO();
		dao.addNewEmployee(employee);
		System.out.println("Employee Added In Table");
		return mapping.findForward("success");
	}
}
