package com.montran.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.dao.EmployeeDAO;
import com.montran.pojo.Employee;

public class EmployeeListAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		EmployeeDAO dao = new EmployeeDAO();
		List<Employee> employeeList = dao.getAllEmployees();

		request.setAttribute("employees", employeeList);

		return mapping.findForward("success");
	}
}
