package com.montran.action;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.dao.IssueDetailsDAO;
import com.montran.form.IssueDetailsForm;
import com.montran.pojo.IssueDetails;

public class IssueNewBookAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		IssueDetailsDAO dao = new IssueDetailsDAO();

		System.out.println("in execute :: IssueNewBookAction");
		Enumeration<String> param = request.getParameterNames();

		while (param.hasMoreElements()) {
			System.out.println("");
			String temp = (String) param.nextElement();

			System.out.println(request.getParameter(temp));
		}
		System.out.println("in execute");
		if (request.getParameter("getMember") != null) {
			System.out.println(request.getParameter("getMember"));
		}
		IssueDetailsForm issueDetailsForm = (IssueDetailsForm) form;

		IssueDetails details = new IssueDetails();
		issueDetailsForm.setIssueCode(dao.issueNewBook(details));
		return mapping.findForward("success");
	}
}
