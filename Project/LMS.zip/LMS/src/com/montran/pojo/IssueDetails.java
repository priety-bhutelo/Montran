package com.montran.pojo;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "book_issue_master")
public class IssueDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "book_issue")
	private int issueCode;

	@Column(name = "date_of_issue")
	private LocalDate issueDate;

	@Column(name = "date_of_return")
	private LocalDate returnDate;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "book_code")
	private Book book;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "member_code")
	private Member member;

	public IssueDetails() {
		// TODO Auto-generated constructor stub
	}

	public IssueDetails(int issueCode, LocalDate issueDate, LocalDate returnDate, Book book, Member member) {
		super();
		this.issueCode = issueCode;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.book = book;
		this.member = member;
	}

	public int getIssueCode() {
		return issueCode;
	}

	public void setIssueCode(int issueCode) {
		this.issueCode = issueCode;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	@Override
	public String toString() {
		return "IssueDetails [issueCode=" + issueCode + ", issueDate=" + issueDate + ", returnDate=" + returnDate
				+ ", book=" + book + ", member=" + member + "]";
	}

}
