package com.montran.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.IssueDetails;
import com.montran.util.SessionFactoryUtil;

public class IssueDetailsDAO {

	private Session session;
	private Transaction transaction;
	private int issueSerialNumber;

	public List<IssueDetails> getAllBookIssueDetails() {
		session = SessionFactoryUtil.getFactory().openSession();
		Query query = session.createQuery("from book_issue_master");
		List<IssueDetails> bookIssueList = query.getResultList();
		session.close();
		return bookIssueList;
	}

	public int issueNewBook(IssueDetails details) {
		session = SessionFactoryUtil.getFactory().openSession();
		transaction = session.beginTransaction();
		issueSerialNumber = (int) session.save(details);
		transaction.commit();
		session.close();
		return issueSerialNumber;
	}
}
