package com.montran.form;

import java.time.LocalDate;

import org.apache.struts.action.ActionForm;

import com.montran.pojo.Book;
import com.montran.pojo.Member;

public class IssueDetailsForm extends ActionForm {
	private int issueCode;
	private int memberCode;
	private String memberName;
	private int bookCode;
	private String title;
	private String author;
	private LocalDate issueDate;
	private LocalDate returnDate;

	private Book book;
	private Member member;

	public int getIssueCode() {
		return issueCode;
	}

	public void setIssueCode(int issueCode) {
		this.issueCode = issueCode;
	}

	public int getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(int memberCode) {
		this.memberCode = memberCode;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public int getBookCode() {
		return bookCode;
	}

	public void setBookCode(int bookCode) {
		this.bookCode = bookCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

}
